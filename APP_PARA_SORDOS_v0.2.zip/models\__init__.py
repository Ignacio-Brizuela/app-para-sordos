"""
Modelos de datos para la aplicación
"""
from .transcription import Transcription, TranscriptionHistory

__all__ = ['Transcription', 'TranscriptionHistory']
