"""
Componentes de interfaz de usuario
"""
from .microphone_screen import MicrophoneScreen

__all__ = ['MicrophoneScreen']
